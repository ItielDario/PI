
class Quarto{

    #numQuarto;

    get numQuarto(){return this.#numQuarto;}
    set numQuarto(numQuarto){this.#numQuarto = numQuarto;}

    constructor(numQuarto){
        this.#numQuarto = numQuarto;
    }
}