
class Hospedagem{

    #acomodacoes;
    #dataSaida;

    get acomodacoes(){return this.#acomodacoes;}
    set acomodacoes(acomodacoes){this.#acomodacoes = acomodacoes;}
    get dataSaida(){return this.#dataSaida;}
    set dataSaida(dataSaida){this.#dataSaida = dataSaida;}

    constructor(acomodacoes,dataSaida){
        this.#acomodacoes = [];
        this.#dataSaida = dataSaida ;
    }

    realizaCheckin(idReserva){
        
    }
}