

class Fisica extends Pessoa{

    #cpf
    #dataNascimento
    #sexo

    get cpf(){return this.#cpf;}
    set cpf(cpf){this.#cpf = cpf;}
    get dataNascimento(){return this.#dataNascimento;}
    set dataNascimento(dataNascimento){this.#dataNascimento = dataNascimento;}
    get sexo(){return this.#sexo;}
    set sexo(sexo){this.#sexo = sexo;}

    constructor(cpf,dataNascimento,sexo){
        this.#cpf = cpf
        this.#dataNascimento = dataNascimento
        this.#sexo = sexo
    }
}