
class ItensServico{

    #precoServico

    get precoServico(){return this.#precoServico;}
    set precoServico(precoServico){this.#precoServico = precoServico;}

    constructor(precoServico){
        this.#precoServico = precoServico;
    }
}