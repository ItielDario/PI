
class TipoAcomodacao{

    #tipoQuarto;
    #precoQuarto;

    get tipoQuarto(){return this.#tipoQuarto;}
    set tipoQuarto(tipoQuarto){this.#tipoQuarto = tipoQuarto;}
    get precoQuarto(){return this.#precoQuarto;}
    set precoQuarto(precoQuarto){this.#precoQuarto = precoQuarto;}

    constructor(tipoQuarto,precoQuarto){

        this.#tipoQuarto = tipoQuarto;
        this.#precoQuarto = precoQuarto;
    }
}