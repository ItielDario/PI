
class Pessoa{

    #nome;
    #telefone;
    #email;
    #dataNascimento;


    get nome(){return this.#nome;}
    set nome(nome){this.#nome = nome;}
    get telefone(){return this.#telefone;}
    set telefone(telefone){this.#telefone = telefone;}
    get email(){return this.#email;}
    set email(email){this.#email = email;}
    get dataNascimento(){return this.#dataNascimento;}
    set dataNascimento(dataNascimento){this.#dataNascimento = dataNascimento;}

    constructor(nome,telefone,email,dataNascimento){
        this.#nome = nome;
        this.#telefone = telefone;
        this.#email = email;
        this.#dataNascimento = dataNascimento;
    }

    getHospede(identificacao){
        
    }
                                
}