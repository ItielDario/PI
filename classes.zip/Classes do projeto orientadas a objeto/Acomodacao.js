
class Acomodacao{

    #quarto
    #qtdDias
    #precoDiaria
    #consumo
    #precoConsumo
    #valorTotal

    get quarto(){return this.#quarto;}
    set quarto(quarto){this.#quarto = quarto;}
    get qtdDias(){return this.#qtdDias;}
    set qtdDias(qtdDias){this.#qtdDias = qtdDias;}
    get precoDiaria(){return this.#precoDiaria;}
    set precoDiaria(precoDiaria){this.#precoDiaria = precoDiaria;}
    get consumo(){return this.#consumo;}
    set consumo(consumo){this.#consumo = consumo;}
    get precoConsumo(){return this.#precoConsumo;}
    set precoConsumo(precoConsumo){this.#precoConsumo = precoConsumo;}
    get valorTotal(){return this.#valorTotal;}
    set valorTotal(valorTotal){this.#valorTotal = valorTotal;}
    
    constructor(quarto,qtdDias,precoDiaria,consumo,precoConsumo,valorTotal){
        this.#quarto = quarto;
        this.#qtdDias = qtdDias;
        this.#precoDiaria = precoDiaria;
        this.#consumo = [];
        this.#precoConsumo = precoConsumo;
        this.#valorTotal = valorTotal;
    }

    listarConsumo(){

    }
    realizarCheckout(idAcomodacao){

    }
}