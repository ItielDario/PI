
class Endereco{

    #cidade;
    #estado;
    #numero;
    #bairro;
    #cep;
    #complemento;

    get cidade(){return this.#cidade;}
    set cidade(cidade){this.#cidade = cidade;}
    get estado(){return this.#estado;}
    set estado(estado){this.#estado = estado;}
    get numero(){return this.#numero;}
    set numero(numero){this.#numero = numero;}
    get bairro(){return this.#bairro;}
    set bairro(bairro){this.#bairro = bairro;}
    get cep(){return this.#cep;}
    set cep(cep){this.#cep = cep;}
    get complemento(){return this.#complemento;}
    set complemento(complemento){this.#complemento = complemento;}

    constructor(cidade,estado,numero,bairro,cep,complemento){
        this.#cidade = cidade;
        this.#estado = estado;
        this.#numero = numero;
        this.#bairro = bairro;
        this.#cep = cep;
        this.complemento = complemento;
    }
}