
class ItensProduto{

    #precoProduto

    get precoProduto(){return this.#precoProduto;}
    set precoProduto(precoProduto){this.#precoProduto = precoProduto;}

    constructor(precoProduto){
        this.#precoProduto = precoProduto;
    }
}