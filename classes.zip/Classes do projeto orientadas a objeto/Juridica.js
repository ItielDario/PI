
class Juridica extends Pessoa{

    #cnpj

    get cnpj(){return this.#cnpj;}
    set cnpj(cnpj){this.#cnpj = cnpj;}

    constructor(cnpj){
        this.#cnpj = cnpj
    }
}