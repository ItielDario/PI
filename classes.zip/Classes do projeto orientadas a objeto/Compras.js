
class Compras{

    #nomeProduto
    #qtdProduto

    get nomeProduto(){return this.#nomeProduto;}
    set nomeProduto(nomeProduto){this.#nomeProduto = nomeProduto;}
    get qtdProduto(){return this.#qtdProduto;}
    set qtdProduto(qtdProduto){this.#qtdProduto = qtdProduto;}

    constructor(nomeProduto,qtdProduto){

        this.#nomeProduto = nomeProduto;
        this.#qtdProduto = qtdProduto;
    }
}