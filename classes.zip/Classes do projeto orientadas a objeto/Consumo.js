
class Consumo{

    #qtdServico
    #qtdProduto
    #nomeProduto
    #nomeServico

    get qtdServico(){return this.#qtdServico;}
    set cnpj(qtdServico){this.#qtdServico = qtdServico;}
    get qtdProduto(){return this.#qtdProduto;}
    set qtdProduto(qtdProduto){this.#qtdProduto = qtdProduto;}
    get nomeProduto(){return this.#nomeProduto;}
    set nomeProduto(nomeProduto){this.#nomeProduto = nomeProduto;}
    get nomeServico(){return this.#nomeServico;}
    set nomeServico(nomeServico){this.#nomeServico = nomeServico;}

    constructor(qtdServico,qtdProduto,nomeProduto,nomeServico){
        this.#qtdServico = qtdServico
        this.#qtdProduto = qtdProduto
        this.#nomeProduto = nomeProduto
        this.#nomeServico = nomeServico
    }
}