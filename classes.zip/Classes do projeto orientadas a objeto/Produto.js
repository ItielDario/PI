
class Produto{

    #nomeProduto

    get nomeProduto(){return this.#nomeProduto;}
    set nomeProduto(nomeProduto){this.#nomeProduto = nomeProduto;}

    constructor(nomeProduto){
        this.#nomeProduto = nomeProduto
    }
}