
class Servico{

    #nomeServico

    get nomeServico(){return this.#nomeServico;}
    set nomeServico(nomeServico){this.#nomeServico = nomeServico;}

    constructor(nomeServico){
        this.#nomeServico = nomeServico;
    }
}