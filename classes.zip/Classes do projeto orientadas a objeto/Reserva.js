
class Reserva{

    #quartos;
    #dataReserva;
    #qtdDias;
    #qtdPessoas;

    get quartos(){return this.#quartos;}
    set quartos(quartos){this.#quartos = quartos;}
    get dataReserva(){return this.#dataReserva;}
    set dataReserva(dataReserva){this.#dataReserva = dataReserva;}
    get qtdDias(){return this.#qtdDias;}
    set qtdDias(qtdDias){this.#qtdDias = qtdDias;}
    get qtdPessoas(){return this.#qtdPessoas;}
    set qtdPessoas(qtdPessoas){this.#qtdPessoas = qtdPessoas;}

    constructor(quartos, dataReserva,qtdDias,qtdPessoas){
        this.quartos = [];
        this.#dataReserva = dataReserva;
        this.#qtdDias = qtdDias;
        this.#qtdPessoas = qtdPessoas;
    }

    getReserva(codReserva){

    }
}